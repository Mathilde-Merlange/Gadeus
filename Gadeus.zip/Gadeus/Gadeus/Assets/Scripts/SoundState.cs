﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundState : MonoBehaviour
{
	public static SoundState Instance;
	public AudioClip playerShotSound; // son associé au tir
	public AudioClip asteroidTouchSound; // son associé à la destruction de l'astéroïde
	
    // Start is called before the first frame update
    void Start()
    {
        if (Instance == null) {
			Instance = this;
			DontDestroyOnLoad (Instance.gameObject);
		}
		else if (this != Instance) {
			Debug.Log ("Detruit");
			Destroy (this.gameObject);
		}
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public void shotButtonSound()
	{
		MakeSound(playerShotSound);
	}
    
    public void touchButtonSound()
	{
		MakeSound(asteroidTouchSound);
	}
	
	/// Play a sound
	private void MakeSound(AudioClip originalClip)
	{
		AudioSource.PlayClipAtPoint(originalClip, transform.position);
	}
}
