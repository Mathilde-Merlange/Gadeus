﻿// ship behaviours
//user interactions
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine. SceneManagement;

public class moveShip : MonoBehaviour
{
	public Vector2 speed;
	private Vector2 movement;
	public Vector2 touchPosition;
	
	double HB;
	double GD;
	
	// Start is called before the first frame update
	void Start()
	{
	}

	// Update is called once per frame
	void Update()
	{
		// déplacement du vaisseau au clavier
		float inputY = Input.GetAxis("Vertical");
		float inputX = Input.GetAxis("Horizontal");
		
		movement= new Vector2 (speed.x * inputX, speed.y * inputY);
		GetComponent<Rigidbody2D> ().velocity = movement;
		
		
		// déplacement du vaisseau au toucher (mode portrait)
		if (Screen.orientation==ScreenOrientation.Portrait || Screen.orientation==ScreenOrientation.PortraitUpsideDown){
			double GD = Screen.width / 2.0;
			double HB = Screen.height / 2.0;
			if(Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Stationary){
			 Vector2 touchPosition = Input.GetTouch(0).position;
			 if(touchPosition.y < HB-(HB/2)){
				 gameObject.transform.Translate(Vector3.down * 5 * Time.deltaTime);
			 } if (touchPosition.y > HB+(HB/2)) {
				 gameObject.transform.Translate(Vector3.up * 5 * Time.deltaTime);
			 }if(touchPosition.x < GD-(GD/2)){
				 gameObject.transform.Translate(Vector3.left * 5 * Time.deltaTime);
			 } if (touchPosition.x > GD+(GD/2)) {
				 gameObject.transform.Translate(Vector3.right * 5 * Time.deltaTime);
			 }
		}
			
		} else{// déplacement du vaisseau au toucher (mode paysage)
			double GD = Screen.height / 2.0;
			double HB = Screen.width / 2.0;
			if(Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Stationary){
			 Vector2 touchPosition = Input.GetTouch(0).position;
			 if(touchPosition.x < HB-(HB/2)){
				 gameObject.transform.Translate(Vector3.left * 5 * Time.deltaTime);
			 } if (touchPosition.x > HB+(HB/2)) {
				 gameObject.transform.Translate(Vector3.right * 5 * Time.deltaTime);
			 }if(touchPosition.y < GD-(GD/2)){
				 gameObject.transform.Translate(Vector3.down * 5 * Time.deltaTime);
			 } if (touchPosition.y > GD+(GD/2)) {
				 gameObject.transform.Translate(Vector3.up * 5 * Time.deltaTime);
			 }
			}
		}
		// Relancer le jeu après le GAME OVER
		bool rt = Input.GetKeyDown (KeyCode.Return);
		if(rt){
			Debug.Log("try again");
			SceneManager.LoadScene("scene1");	
		}
		if(Input.touchCount == 3 && Input.GetTouch(0).phase == TouchPhase.Began){
			Debug.Log("try again");
			SceneManager.LoadScene("scene1");
		}
		
	}
	
	void OnTriggerEnter2D(Collider2D collider) {
		if(collider.name == "Asteroid" || collider.name =="Asteroid(Clone)"){
			if (GameObject.FindGameObjectWithTag("life1"))
				GameObject.FindGameObjectWithTag("life1").AddComponent<fadeOut>();
			else if (GameObject.FindGameObjectWithTag("life2"))
				GameObject.FindGameObjectWithTag("life2").AddComponent<fadeOut>();
			else if (GameObject.FindGameObjectWithTag("life3"))
				GameObject.FindGameObjectWithTag("life3").AddComponent<fadeOut>();
			else if (GameObject.FindGameObjectWithTag("life4"))
				GameObject.FindGameObjectWithTag("life4").AddComponent<fadeOut>();
			else if (GameObject.FindGameObjectWithTag("life5"))
				{
					GameObject.FindGameObjectWithTag("life5").AddComponent<fadeOut>();
					// Game Over
					Time.timeScale = 0;
					GameState.Instance.endgame();
					
				}
		}
	}

}
