﻿//déplacements des tirs
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveShoot : MonoBehaviour
{
	private Vector3 rightTopCameraBorder;
	private Vector3 leftTopCameraBorder;
	private Vector3 rightBottomCameraBorder;
	private Vector3 leftBottomCameraBorder;
	
	private Vector3 siz;
	public Vector2 speed;
	private Vector2 movement;
	
    // Start is called before the first frame update
    void Start()
    {
        leftBottomCameraBorder=Camera.main.ViewportToWorldPoint(new Vector3(0,0,0));
        leftTopCameraBorder=Camera.main.ViewportToWorldPoint(new Vector3(0,1,0));
        rightBottomCameraBorder=Camera.main.ViewportToWorldPoint(new Vector3(1,0,0));
        rightTopCameraBorder=Camera.main.ViewportToWorldPoint(new Vector3(1,1,0));
    }

    // Update is called once per frame
    void Update()
    {
        siz.x=gameObject.GetComponent<SpriteRenderer> ().bounds.size.x;
        siz.y=gameObject.GetComponent<SpriteRenderer> ().bounds.size.y;
        movement= new Vector2 (speed.x,0);
        GetComponent<Rigidbody2D> ().velocity = movement;
        if(transform.position.x > rightBottomCameraBorder.x + (siz.x/2)){
			Destroy (gameObject);
		}
    }
    
    void OnTriggerEnter2D(Collider2D collider) {
		if(collider.name == "Asteroid" || collider.name =="Asteroid(Clone)"){
			SoundState.Instance.touchButtonSound();
			GameState.Instance.addScorePlayer(1);
			// Add the fade script to the gameObject containing this script
			collider.gameObject.AddComponent<fadeOut>();
			// Shoot destroy
			Destroy (gameObject);
		}
		
	}
}
