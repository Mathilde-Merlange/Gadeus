﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameState : MonoBehaviour
{
	public static GameState Instance;
	private int scorePlayer=0;
	private string ending=""; // message de fin de partie
	
    // Start is called before the first frame update
    void Start()
    {
		if (Instance == null) {
			Instance = this;
			DontDestroyOnLoad (Instance.gameObject);
		}
		else if (this != Instance) {
			Debug.Log ("Detruit");
			Destroy (this.gameObject);
		}   
    }

    // Update is called once per frame
    void Update()
    {
       GameObject.FindWithTag ("scoreLabel").GetComponent<Text>().text = "" + scorePlayer + ending; 
    }
    
    public void addScorePlayer(int toAdd) {
		scorePlayer += toAdd;
	}
	
	public int getScorePlayer(){
		return scorePlayer;
	}
	
	public void endgame(){
		ending=" GAME OVER";
	}
}
