﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class detectIfAsteroid : MonoBehaviour
{
	private Vector3 rightTopCameraBorder;
	private Vector3 rightBottomCameraBorder;
	private Vector3 siz;
	public GameObject[] respawns;
	
    // Start is called before the first frame update
    void Start()
    {
        rightBottomCameraBorder=Camera.main.ViewportToWorldPoint(new Vector3(1,0,0));
        rightTopCameraBorder=Camera.main.ViewportToWorldPoint(new Vector3(1,1,0));
        InvokeRepeating("respawn", 0.0f, 0.8f);
    }

    // Update is called once per frame
    void Update()
    {
    }
    
    void respawn()
    {
		// Create a tab containing all the asteroid in a scene
		respawns = GameObject.FindGameObjectsWithTag("asteroid");
		// If less than 10 asteroids ...
		if (respawns.Length > 0) {
			siz.x = respawns[0].GetComponent<SpriteRenderer> ().bounds.size.x;
			siz.y = respawns[0].GetComponent<SpriteRenderer> ().bounds.size.y;
		}
		// ...
		if (respawns.Length < 10){
			// Choose randomly if an asteroid will be created or not
			if (Random.Range(1,100) == 50 || respawns.Length < 4){
				// Create a new asteroid
				Vector3 tmpPos = new Vector3 (rightBottomCameraBorder.x + (siz.x / 2),Random.Range (rightBottomCameraBorder.y + (siz.y / 2),(rightTopCameraBorder.y - (siz.y / 2))),transform.position.z);
				// Instanciation
				GameObject gY = Instantiate (Resources.Load ("Asteroid"), tmpPos, Quaternion.identity) as GameObject;
			}
		}
	}
}
