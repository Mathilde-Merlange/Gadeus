﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class moveAsteroid : MonoBehaviour
{
	public Vector2 speed;
	private Vector2 movement;
	private Vector3 siz;
	
	private Vector3 rightTopCameraBorder;
	private Vector3 leftTopCameraBorder;
	private Vector3 rightBottomCameraBorder;
	private Vector3 leftBottomCameraBorder;
	
	public Vector3 tmpPos;
	
    // Start is called before the first frame update
    void Start()
    {
        leftBottomCameraBorder=Camera.main.ViewportToWorldPoint(new Vector3(0,0,0));
        leftTopCameraBorder=Camera.main.ViewportToWorldPoint(new Vector3(0,1,0));
        rightBottomCameraBorder=Camera.main.ViewportToWorldPoint(new Vector3(1,0,0));
        rightTopCameraBorder=Camera.main.ViewportToWorldPoint(new Vector3(1,1,0));
    }

    // Update is called once per frame
    void Update()
    {
		//déplacement d'un astéroïde
		siz.x=gameObject.GetComponent<SpriteRenderer> ().bounds.size.x;
        siz.y=gameObject.GetComponent<SpriteRenderer> ().bounds.size.y;
        movement= new Vector2 (-speed.x,0);
        GetComponent<Rigidbody2D> ().velocity = movement;
        //création d'un nouvel astéroïde 
        if(transform.position.x < leftBottomCameraBorder.x + (siz.x/2)){
			float r=Random.Range(leftTopCameraBorder.y,leftBottomCameraBorder.y);
			gameObject.transform.position = new Vector3(rightBottomCameraBorder.x+(siz.x/2),r,transform.position.z);
			tmpPos=gameObject.transform.position;
			GameObject clone1=Instantiate(Resources.Load("Asteroid"),tmpPos,Quaternion.identity) as GameObject;
			Destroy(gameObject);
		}
			
    }
}
